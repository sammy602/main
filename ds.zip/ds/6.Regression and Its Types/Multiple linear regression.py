import pandas as pd
from sklearn.linear_model import LinearRegression

# Dataset
df = pd.DataFrame({
    'Area': [800, 1000, 1200, 1500],
    'Bedrooms': [2, 3, 3, 4],
    'Price': [40, 55, 65, 80]
})

X = df[['Area', 'Bedrooms']]
y = df['Price']

# Model
model = LinearRegression()
model.fit(X, y)

# Coefficients
print("Intercept:", model.intercept_)
print("Coefficients:", model.coef_)
