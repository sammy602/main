import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# --- Dataset ---
X = np.array([1, 2, 3, 4, 5]).reshape(-1, 1)   # independent variable
y = np.array([2, 4, 5, 4, 5])                  # dependent variable

# --- Create and train the model ---
model = LinearRegression()
model.fit(X, y)

# --- Predictions ---
y_pred = model.predict(X)

# --- Print slope and intercept ---
print("Slope (Coefficient):", model.coef_[0])
print("Intercept:", model.intercept_)

# --- Plotting ---
plt.scatter(X, y)                # actual data points
plt.plot(X, y_pred)              # regression line
plt.title("Simple Linear Regression")
plt.xlabel("Hours Studied")
plt.ylabel("Marks Scored")
plt.grid(True)
plt.show()
