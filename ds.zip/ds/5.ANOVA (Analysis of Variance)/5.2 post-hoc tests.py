#required statsmodels module to install
#open cmd and run following command
#pip install statsmodels

import pandas as pd
from statsmodels.stats.multicomp import pairwise_tukeyhsd

# DataFrame with 3 groups
data = {
    "Group": ["A","A","A", "B","B","B", "C","C","C"],
    "Value": [2, 3, 4, 5, 6, 7, 8, 9, 10]
}

df = pd.DataFrame(data)

# --- Simple Post-Hoc Test (Tukey HSD) ---
tukey = pairwise_tukeyhsd(endog=df["Value"],groups=df["Group"],alpha=0.05)
print(tukey)


#Multiple Comparison of Means - Tukey HSD
#========================================
#group1 group2 meandiff p-adj  lower upper reject
#------------------------------------------------
#A      B        3.0   0.001   True
#A      C        6.0   0.001   True
#B      C        3.0   0.001   True
#------------------------------------------------
#✔ reject = True means the groups are significantly different.
#✔ In this example, all groups differ (A≠B, A≠C, B≠C).
