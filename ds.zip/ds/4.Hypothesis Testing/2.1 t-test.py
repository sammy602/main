
#A company claims the average salary of employees is ₹50,000.
#We want to test whether the actual average salary is different.
#Null Hypothesis (H₀): Mean salary = 50,000
#Alternative Hypothesis (H₁): Mean salary ≠ 50,000

import numpy as np
from scipy import stats

# Sample salary data (in Rs.)
salary = np.array([47000, 52000, 51000, 48000, 53000, 49500, 50500])

# Hypothesized population mean
mu_0 = 50000

# 1-sample t-test
t_stat, p_value = stats.ttest_1samp(salary, mu_0)

print("T-statistic:", t_stat)
print("P-value:", p_value)

#If p-value < 0.05 → Reject Null Hypothesis (H₀)
#If p-value ≥ 0.05 → Fail to Reject Null Hypothesis
if(p_value<0.05):
    print("Reject Null Hypothesis (H₀)")
elif(p_value>=0.05):
    print("Fail to Reject Null Hypothesis H₀")
else:
    print("No more statistic data found")
