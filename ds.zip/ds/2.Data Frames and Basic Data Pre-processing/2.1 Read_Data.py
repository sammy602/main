# Read data from a csv file
import pandas as pd
df = pd.read_csv('Student_Marks.csv')
print("="*10)
print("CSV Data")
print("="*10)
print(df)


print("="*10)
print("JSON Data")
print("="*10)

data = pd.read_json('employees.json')
print(data)
