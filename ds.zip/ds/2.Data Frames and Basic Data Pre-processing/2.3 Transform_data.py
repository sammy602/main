import pandas as pd
df = pd.read_csv('Student_Marks.csv')
print(df)

print("\nStudents from Sciecne Stream")
filtered_df = df[df['stream'] == 'Science']
print(filtered_df)


print("\nStudents having per >90")
high_Per = df[df['per'] > 90]
print(high_Per)

print("\nStudents having per >90 and from Science Stream")
high_Per_stm = df[(df['per'] > 90) & (df['stream'] == 'Science')]
print(high_Per_stm)


print("\nSorting Students data by Per column")
sorted_df = df.sort_values(by='per', ascending=False)
print(sorted_df)

sorted_df.to_csv("filtered_sorted_Student_Marks.csv", index=False)

