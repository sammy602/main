import pandas as pd
df = pd.read_csv('Enrollment.csv')
print(df)
print("Dataset after filling NA: ")
df2=df['Age'].fillna(18)
print(df2)
print("Dataset after Droping NA: ")
df3=df.dropna()
print(df3)
