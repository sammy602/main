import pandas as pd

# Single dimensional data
df = pd.DataFrame({'Age': [20,30,40]})

print("Original Data:")
print(df)

#Standardization (Z-score Scaling)
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

df['Age_std'] = scaler.fit_transform(df[['Age']])

print("\nAfter Standardization:")
print(df)


#Normalization (Min–Max Scaling)
from sklearn.preprocessing import MinMaxScaler

normalizer = MinMaxScaler()
df['Age_norm'] = normalizer.fit_transform(df[['Age']])
print("\nAfter Normalization:")
print(df)
