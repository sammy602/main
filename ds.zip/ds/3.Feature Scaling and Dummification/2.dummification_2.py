import pandas as pd

df = pd.DataFrame({
    'Gender': ['Male', 'Female', 'Male'],
    'City': ['Pune', 'Delhi', 'Mumbai']
})
print("Original Data\n")
print(df)
df_encoded = pd.get_dummies(df)
print(df_encoded)
