import pandas as pd

# Sample data
df = pd.DataFrame({
    'City': ['Mumbai', 'Delhi', 'Pune', 'Mumbai']
})

print("Original DataFrame:")
print(df)

# Perform dummification
df_dummies = pd.get_dummies(df, columns=['City'])

print("\nAfter Dummification:")
print(df_dummies)
