# Step 1: Import required libraries
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
# Step 2: Create simple dataset
# Example: Study Hours & Attendance → Pass(1) / Fail(0)
X = [
    [1, 50],   # 1 hour study, 50% attendance
    [2, 60],
    [3, 65],
    [4, 70],
    [5, 75],
    [6, 80],
    [7, 85],
    [8, 90]
]
y = [0, 0, 0, 0, 1, 1, 1, 1]  # 0 = Fail, 1 = Pass

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42) # Step 3: Split dataset
model = DecisionTreeClassifier() # Step 4: Create Decision Tree model

model.fit(X_train, y_train) # Step 5: Train model

y_pred = model.predict(X_test) # Step 6: Make predictions

print("Accuracy:", accuracy_score(y_test, y_pred)) # Step 7: Check accuracy

feature_names = ["Study_Hours", "Attendance"] # Step 8: Print decision rules

tree_rules = export_text(model, feature_names=feature_names)
print("\nDecision Tree Rules:\n")
print(tree_rules)











