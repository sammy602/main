import pandas as pd
from sklearn.linear_model import LogisticRegression

# Dataset
df = pd.DataFrame({
    'Hours': [2, 4, 6, 8],
    'Result': [0, 0, 1, 1]
})

X = df[['Hours']]
y = df['Result']

# Model
model = LogisticRegression()
model.fit(X, y)

# Prediction
pred = model.predict([[2]])

print("Predicted Class:", pred[0])

